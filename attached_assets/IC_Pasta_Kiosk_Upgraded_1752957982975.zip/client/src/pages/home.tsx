import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { IceCream, Settings, ArrowRight, ShoppingCart, Users } from "lucide-react";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { GuestBanner, OrderingTips } from "@/components/ui/guest-banner";
import { useKeyboardNavigation } from "@/hooks/useKeyboardNavigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useOrder } from "@/hooks/use-order";
import StepOne from "@/components/ordering/step-one";
import StepTwo from "@/components/ordering/step-two";
import StepThree from "@/components/ordering/step-three";
import OrderSummary from "@/components/ordering/order-summary";
import OrderConfirmation from "@/components/ordering/order-confirmation";
import FreezeSticksFlow from "@/components/ordering/freeze-sticks-flow";
import PintsFlow from "@/components/ordering/pints-flow";
import EasyCart from "@/components/cart/easy-cart";
import OrderWrapper from "@/components/ordering/order-wrapper";
import { useCart } from "@/hooks/use-cart";
import { useLocation } from "wouter";
import type { Menu, Cart } from "@shared/schema";

export default function Home() {
  const [, setLocation] = useLocation();
  const [selectedMenu, setSelectedMenu] = useState<Menu | null>(null);
  const [showCartDialog, setShowCartDialog] = useState(false);
  const [showCartViewer, setShowCartViewer] = useState(false);
  const [customerName, setCustomerName] = useState<string>('');
  const { currentStep, order, totalPrice, resetOrder, setSelectedMenuId, setStep } = useOrder();
  const { cartId, items, isActive, setCartId, addItem } = useCart();

  // QR code and guest info state
  const [qrInfo, setQrInfo] = useState<{ table?: string; location?: string }>({});
  const [showGuestBanner, setShowGuestBanner] = useState(false);

  // Reset order state when component mounts to start fresh
  useEffect(() => {
    // Clear any persistent order state to start fresh
    resetOrder();
    
    // Check for QR code parameters in URL
    const urlParams = new URLSearchParams(window.location.search);
    const tableNumber = urlParams.get('table');
    const location = urlParams.get('location');
    
    if (tableNumber) {
      // Store QR code info for later use in orders
      localStorage.setItem('qr_table', tableNumber);
      if (location) {
        localStorage.setItem('qr_location', location);
      }
      setQrInfo({ table: tableNumber, location: location || undefined });
      setShowGuestBanner(true);
      console.log(`QR Code detected: Table ${tableNumber}${location ? ` at ${location}` : ''}`);
    }
  }, []);

  const { data: menus = [], isLoading: menusLoading, error: menusError } = useQuery<Menu[]>({
    queryKey: ["/api/menus"],
  });

  // Sort menus by featured status or popularity
  const sortedMenus = [...menus].sort((a, b) => {
    // Featured menus first, then by order of creation
    return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
  });

  const handleMenuSelect = (menu: Menu) => {
    setSelectedMenu(menu);
    setSelectedMenuId(menu.id);
    
    // Route to appropriate flow based on menu type
    switch (menu.orderingFlow) {
      case "single-page":
        setStep(5); // Single page flow
        break;
      case "custom":
        setStep(6); // Custom flow (freeze sticks, etc.)
        break;
      default:
        setStep(1); // Traditional 3-step flow
    }
  };

  const renderMenuSelection = () => {
    if (menusLoading) {
      return (
        <div className="space-y-8">
          <div className="text-center">
            <h2 className="text-4xl font-bold text-dark-slate mb-4">Choose Your Experience</h2>
            <LoadingSpinner size="lg">Loading menu options...</LoadingSpinner>
          </div>
        </div>
      );
    }

    if (menusError) {
      return (
        <div className="space-y-8">
          <div className="text-center">
            <h2 className="text-4xl font-bold text-dark-slate mb-4">Choose Your Experience</h2>
            <p className="text-red-600">Unable to load menu options. Please try refreshing the page.</p>
          </div>
        </div>
      );
    }

    return (
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-dark-slate mb-4">Choose Your Experience</h1>
          <p className="text-gray-600 text-xl">Select from our delicious menu options</p>
        </div>

        {/* --- FIX FOR ACCESSIBILITY & IMAGE SUPPORT IN MENU CARDS --- */}
        {/* 1. Card is keyboard-accessible and selectable by Enter/Space. */}
        {/* 2. Card uses aria-label for screen readers. */}
        {/* 3. Menu images are shown if present, with alt text for accessibility. */}
        {/* 4. Fallback to IceCream icon if no image exists. */}
        {/* 5. Button uses clear aria-label for screen readers. */}
        {/* 6. Card and button use clear focus and hover styles for kiosk UX. */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" role="group" aria-label="Menu selection">
          {sortedMenus.map((menu: Menu) => (
            <Card
              key={menu.id}
              tabIndex={0} // Make the card keyboard focusable
              aria-label={`Select ${menu.name} menu - ${menu.description || ''}`}
              className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:border-primary focus:shadow-lg btn-focus"
              // Handle keyboard selection as well as click
              onClick={() => handleMenuSelect(menu)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleMenuSelect(menu);
                }
              }}
            >
              <CardContent className="p-8 text-center">
                {/* Show menu image if available, otherwise fallback to icon */}
                {menu.imageUrl ? (
                  <img
                    src={menu.imageUrl}
                    alt={`${menu.name} preview`}
                    className="w-20 h-20 mx-auto mb-4 rounded-lg shadow object-cover"
                  />
                ) : (
                  <div className="w-20 h-20 bg-gradient-to-br from-primary to-secondary rounded-full mx-auto mb-4 flex items-center justify-center">
                    <IceCream className="w-10 h-10 text-white" aria-hidden="true" />
                  </div>
                )}

                <div className="text-2xl font-bold mb-2 text-dark-slate">{menu.name}</div>
                <div className="text-muted-foreground mb-4 text-sm">{menu.description}</div>

                <Button
                  className="w-full bg-primary hover:bg-primary/90 text-white focus:ring-2 focus:ring-primary focus:ring-offset-2 btn-focus"
                  aria-label={`Start ${menu.name} order`}
                  tabIndex={-1} // Card handles focus, not individual button
                >
                  Start Order
                  <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  };

  const renderProgressBar = () => {
    const steps = [
      { number: 1, label: "Base", completed: currentStep > 1 },
      { number: 2, label: "Sauce", completed: currentStep > 2 },
      { number: 3, label: "Toppings", completed: currentStep > 3 },
    ];

    return (
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8" role="progressbar" aria-valuenow={currentStep} aria-valuemin={1} aria-valuemax={3} aria-label="Order progress">
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setStep(0)}
                  className="text-xs"
                >
                  ← Change Menu
                </Button>
                {selectedMenu && (
                  <span className="text-sm text-gray-600 font-medium">
                    {selectedMenu.name} Menu
                  </span>
                )}
              </div>
              <div className="flex items-center space-x-8">
                {steps.map((step, index) => (
                  <div key={step.number} className="flex items-center">
                    <div className="flex items-center space-x-2">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                          currentStep >= step.number
                            ? "bg-primary text-white"
                            : "bg-gray-300 text-gray-600"
                        }`}
                      >
                        {step.number}
                      </div>
                      <span
                        className={`font-medium ${
                          currentStep >= step.number
                            ? "text-primary"
                            : "text-gray-600"
                        }`}
                      >
                        {step.label}
                      </span>
                    </div>
                    {index < steps.length - 1 && (
                      <div className="w-16 h-1 bg-gray-200 rounded ml-8">
                        <div
                          className={`h-1 rounded transition-all duration-300 ${
                            currentStep > step.number ? "w-full bg-primary" : "w-0"
                          }`}
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Order Total</p>
              <p className="text-2xl font-bold text-primary">${totalPrice.toFixed(2)}</p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderStep = () => {
    if (currentStep === 0) {
      return renderMenuSelection();
    }

    if (!selectedMenu) {
      return renderMenuSelection();
    }

    // Wrap all ordering flows with name collection
    const orderingFlow = () => {
      switch (currentStep) {
        case 1:
          return <StepOne />;
        case 2:
          return <StepTwo />;
        case 3:
          return <StepThree />;
        case 4:
          return <OrderSummary />;
        case 5:
          return <PintsFlow />; // Single page flow
        case 6:
          return <FreezeSticksFlow />; // Custom flow
        default:
          return <StepOne />;
      }
    };

    return (
      <OrderWrapper menu={selectedMenu}>
        {orderingFlow()}
      </OrderWrapper>
    );
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-gradient-to-r from-primary to-secondary text-white py-6 px-4 shadow-lg">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <IceCream className="text-3xl" />
              <h1 className="text-3xl md:text-4xl font-bold">IC Pasta</h1>
            </div>
            <div className="flex items-center gap-3">
              {/* Cart Access - Only show when cart is active */}
              {isActive && (
                <Dialog open={showCartDialog} onOpenChange={setShowCartDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      {cartId} ({items.length})
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>Group Cart</DialogTitle>
                      <DialogDescription>
                        Manage your group orders and share your cart with others
                      </DialogDescription>
                    </DialogHeader>
                    <EasyCart />
                  </DialogContent>
                </Dialog>
              )}

              <div className="text-right">
                <p className="text-sm opacity-90">Welcome!</p>
                <p className="text-lg font-semibold">Start Your Order</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Progress Bar */}
      {currentStep > 0 && currentStep < 5 && renderProgressBar()}
      
      {/* Home Button for non-traditional flows */}
      {currentStep >= 5 && (
        <div className="bg-white shadow-sm">
          <div className="max-w-6xl mx-auto px-4 py-4">
            <Button
              variant="outline"
              onClick={() => {
                resetOrder();
                setSelectedMenu(null);
              }}
              className="text-sm"
            >
              ← Back to Menu Selection
            </Button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {renderStep()}
      </main>

      {/* Admin Button */}
      <Button
        onClick={() => setLocation("/admin")}
        className="fixed bottom-4 right-4 bg-dark-slate text-white p-3 rounded-full shadow-lg hover:bg-gray-800 transition-colors z-40 btn-focus"
        size="icon"
        aria-label="Access admin dashboard"
      >
        <Settings className="h-5 w-5" />
      </Button>
    </div>
  );
}
